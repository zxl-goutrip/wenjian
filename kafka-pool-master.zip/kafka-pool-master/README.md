# kafka-pool
A simple kafka pool implement by Java.
